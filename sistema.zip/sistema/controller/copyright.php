<div class="col-12 col-md-12 text-center">
	<p style="font-size: 10px;">&copy;Todos os direitos reservados - <?php date_default_timezone_set('America/Sao_Paulo'); $data = date ("Y"); echo $data;?></p>
</div>